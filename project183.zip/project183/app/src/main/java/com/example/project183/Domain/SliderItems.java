package com.example.project183.Domain;

public class SliderItems {
    private String image;

    public SliderItems() {
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }
}
