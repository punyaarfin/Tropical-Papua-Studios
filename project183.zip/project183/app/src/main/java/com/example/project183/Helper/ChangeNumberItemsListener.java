package com.example.project183.Helper;

public interface ChangeNumberItemsListener {
    void change();
}
